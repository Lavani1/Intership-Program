﻿Public Class frmMainScreen



    Private Sub FillOutSurveyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FillOutSurveyToolStripMenuItem.Click
        Dim objFillOut As New frmFillOutSurvey
        objFillOut.MdiParent = Me
        objFillOut.Show()

    End Sub

    Private Sub ViewSurveyResultsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewSurveyResultsToolStripMenuItem.Click
        Dim objFillOut As New frmViewSurvey
        objFillOut.MdiParent = Me
        objFillOut.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        If MessageBox.Show("Do you want to exit the Survey?", "READY TO EXIT", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            MessageBox.Show("THANK YOU :)")
            Application.Exit()
        End If
    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        If MessageBox.Show(" Save the Survey?", "READY TO SAVE", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) = Windows.Forms.DialogResult.OK Then
            MessageBox.Show("SURVEY SAVED ;)")

        End If

    End Sub

    Private Sub UpdateTheNameToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateTheNameToolStripMenuItem.Click

    End Sub
End Class
