﻿Module DataModule
    Public arSurveys(20) As UserDetails
    Public arAge(20) As Integer
    Public arCnt As Integer = 0

    Public pizza As Integer = 0
    Public pasta As Integer = 0
    Public papWors As Integer = 0
    Public ChicknFr As Integer = 0
    Public BeefFr As Integer = 0
    Public other As Integer = 0

    Public EatOutRate As Integer = 0
    Public watchMovies As Integer = 0
    Public watchTv As Integer = 0
    Public Lradio As Integer = 0

    Public datte As String = ""
End Module
