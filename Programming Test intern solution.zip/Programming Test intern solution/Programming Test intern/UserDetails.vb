﻿Public Class UserDetails
    Private _surname As String
    Public Property Surname() As String
        Get
            Return _surname
        End Get
        Set(ByVal value As String)
            _surname = value

        End Set
    End Property

    Private _firstNames As String
    Public Property FirstNames() As String
        Get
            Return _firstNames
        End Get
        Set(ByVal value As String)
            _firstNames = value
        End Set
    End Property

    Private _ContactNumber As String
    Public Property ContactNumber() As String
        Get
            Return _ContactNumber
        End Get
        Set(ByVal value As String)
            _ContactNumber = value
        End Set
    End Property

    Private _age As Integer
    Public Property Age() As Integer
        Get
            Return _age
        End Get
        Set(ByVal value As Integer)
            _age = value
        End Set
    End Property

    Public Sub New()
        Surname = ""
        FirstNames = ""
        ContactNumber = ""
    End Sub

    Public Sub New(ByVal PSurname As String, ByVal PFirstName As String, ByVal PContactNum As String)
        Surname = PSurname
        FirstNames = PFirstName
        ContactNumber = PContactNum

    End Sub



    Public Overrides Function ToString() As String
        Return Surname & "," & FirstNames & ";" & ContactNumber & ";" & Age.ToString
    End Function
End Class
