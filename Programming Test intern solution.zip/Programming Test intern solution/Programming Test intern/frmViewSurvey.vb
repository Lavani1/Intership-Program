﻿Option Explicit On
Option Strict On
Public Class frmViewSurvey
    Public Sub ViewData()

        Dim oldest, youngest As Integer

        lstView.Items.Add("TOTAL NUMBER OF SURVEYS     :" & arCnt.ToString)


        oldest = arAge(0)
        For H As Integer = 1 To arCnt - 1
            If arAge(H) > oldest Then
                oldest = arAge(H)
            End If
        Next
        lstView.Items.Add("OLDEST PERSON PARTICIPATED     : " & oldest.ToString)

        youngest = arAge(0)
        For K As Integer = 1 To arCnt - 1
            If arAge(K) < youngest Then
                youngest = arAge(K)
            End If
        Next
        lstView.Items.Add("YOUNGEST PERSON PARTICIPATED     : " & youngest.ToString)

    End Sub


    Public Sub AverageAge()
        Dim sum As Integer = 0
        Dim cnt As Integer
        Dim avg As Double

        For cnt = 0 To arCnt - 1
            sum += arAge(cnt)
        Next

        If arCnt = 0 Then
            avg = 0
        Else
            avg = sum / arCnt
        End If
        lstView.Items.Add("AVERAGE AGE : " & avg.ToString)

    End Sub
    Public Sub FavourateFood()
        Dim likePizza As Double
        Dim likePasta As Double
        Dim likePapAndWors As Double


        likePizza = (pizza / arCnt) * 100
        likePasta = (pasta / arCnt) * 100
        likePapAndWors = (papWors / arCnt) * 100


        lstView.Items.Add("Percentage of people who like Pizza    " & likePizza.ToString("n2") & "%")
        lstView.Items.Add("Percentage of people who like Pasta    " & likePasta.ToString("n2") & "%")
        lstView.Items.Add("Percentage of people who like Pap and Wors    " & likePapAndWors.ToString("n2") & "%")

    End Sub

    Public Sub CalcRate()
        Dim EatOutRatee, WatchMoviess, WatchTvv, Lradioo As Double
        EatOutRatee = EatOutRate / arCnt
        WatchMoviess = watchMovies / arCnt
        WatchTvv = watchTv / arCnt
        Lradioo = Lradio / arCnt

        lstView.Items.Add("People like to Eat Out:    " & EatOutRatee.ToString("n2"))
        lstView.Items.Add("People like to Watch movies:    " & WatchMoviess.ToString("n2"))
        lstView.Items.Add("People like to Watch TV:    " & WatchTvv.ToString("n2"))
        lstView.Items.Add("People like Listen To Radio:    " & Lradioo.ToString("n2"))
    End Sub


    Private Sub frmViewSurvey_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lstView.Items.Clear()
        Call ViewData()
        Call AverageAge()

        lstView.Items.Add("")
        lstView.Items.Add("----------------------------FAVORATE FOOD---------------------------------------------")

        FavourateFood()

        lstView.Items.Add("")
        lstView.Items.Add("----------------------------RATES---------------------------------------------")
        CalcRate()

        'lblDate.Text = datte


    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        If MessageBox.Show("Do you want to close?", "READY TO EXIT!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Me.Close()


        End If
    End Sub


End Class