﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFillOutSurvey
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtDate = New System.Windows.Forms.DateTimePicker()
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.txtContactNum = New System.Windows.Forms.TextBox()
        Me.txtFirstNames = New System.Windows.Forms.TextBox()
        Me.txtSuename = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkOther = New System.Windows.Forms.CheckBox()
        Me.chkBeefStirFry = New System.Windows.Forms.CheckBox()
        Me.chkChickenStirFry = New System.Windows.Forms.CheckBox()
        Me.chkPapWors = New System.Windows.Forms.CheckBox()
        Me.chkPasta = New System.Windows.Forms.CheckBox()
        Me.chkPizza = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.rdoSagreeEatOut = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.rdoSagreeRadio = New System.Windows.Forms.RadioButton()
        Me.rdoSagreeTv = New System.Windows.Forms.RadioButton()
        Me.rdoSagreeMovies = New System.Windows.Forms.RadioButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.rdoAgreeRadio = New System.Windows.Forms.RadioButton()
        Me.rdoAgreeTv = New System.Windows.Forms.RadioButton()
        Me.rdoAgreeMovies = New System.Windows.Forms.RadioButton()
        Me.rdoAgreeEatOut = New System.Windows.Forms.RadioButton()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.rdoDisRadio = New System.Windows.Forms.RadioButton()
        Me.rdoDisTV = New System.Windows.Forms.RadioButton()
        Me.rdoDisMovies = New System.Windows.Forms.RadioButton()
        Me.rdoDisEatOut = New System.Windows.Forms.RadioButton()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.rdoNeutRadio = New System.Windows.Forms.RadioButton()
        Me.rdoNeutTV = New System.Windows.Forms.RadioButton()
        Me.rdoNeutMovies = New System.Windows.Forms.RadioButton()
        Me.rdoNeutEatOut = New System.Windows.Forms.RadioButton()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.rdoSdisRadio = New System.Windows.Forms.RadioButton()
        Me.rdoSdisTV = New System.Windows.Forms.RadioButton()
        Me.rdoSdisMovies = New System.Windows.Forms.RadioButton()
        Me.rdoSdisEatOut = New System.Windows.Forms.RadioButton()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Take Your Survey"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(58, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Surname :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(45, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "First Names :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Contact Number :"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtDate)
        Me.GroupBox1.Controls.Add(Me.txtAge)
        Me.GroupBox1.Controls.Add(Me.txtContactNum)
        Me.GroupBox1.Controls.Add(Me.txtFirstNames)
        Me.GroupBox1.Controls.Add(Me.txtSuename)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Location = New System.Drawing.Point(118, 53)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(290, 180)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal Details"
        '
        'dtDate
        '
        Me.dtDate.Location = New System.Drawing.Point(133, 114)
        Me.dtDate.Name = "dtDate"
        Me.dtDate.Size = New System.Drawing.Size(100, 20)
        Me.dtDate.TabIndex = 9
        '
        'txtAge
        '
        Me.txtAge.Location = New System.Drawing.Point(133, 140)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(51, 20)
        Me.txtAge.TabIndex = 11
        '
        'txtContactNum
        '
        Me.txtContactNum.Location = New System.Drawing.Point(133, 88)
        Me.txtContactNum.Name = "txtContactNum"
        Me.txtContactNum.Size = New System.Drawing.Size(100, 20)
        Me.txtContactNum.TabIndex = 9
        '
        'txtFirstNames
        '
        Me.txtFirstNames.Location = New System.Drawing.Point(133, 57)
        Me.txtFirstNames.Name = "txtFirstNames"
        Me.txtFirstNames.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstNames.TabIndex = 8
        '
        'txtSuename
        '
        Me.txtSuename.Location = New System.Drawing.Point(133, 28)
        Me.txtSuename.Name = "txtSuename"
        Me.txtSuename.Size = New System.Drawing.Size(100, 20)
        Me.txtSuename.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(81, 140)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Age :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(77, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Date :"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkOther)
        Me.GroupBox2.Controls.Add(Me.chkBeefStirFry)
        Me.GroupBox2.Controls.Add(Me.chkChickenStirFry)
        Me.GroupBox2.Controls.Add(Me.chkPapWors)
        Me.GroupBox2.Controls.Add(Me.chkPasta)
        Me.GroupBox2.Controls.Add(Me.chkPizza)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(118, 239)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(290, 192)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "What Is Your Favourte Food?"
        '
        'chkOther
        '
        Me.chkOther.AutoSize = True
        Me.chkOther.Location = New System.Drawing.Point(9, 164)
        Me.chkOther.Name = "chkOther"
        Me.chkOther.Size = New System.Drawing.Size(52, 17)
        Me.chkOther.TabIndex = 18
        Me.chkOther.Text = "Other"
        Me.chkOther.UseVisualStyleBackColor = True
        '
        'chkBeefStirFry
        '
        Me.chkBeefStirFry.AutoSize = True
        Me.chkBeefStirFry.Location = New System.Drawing.Point(9, 141)
        Me.chkBeefStirFry.Name = "chkBeefStirFry"
        Me.chkBeefStirFry.Size = New System.Drawing.Size(83, 17)
        Me.chkBeefStirFry.TabIndex = 17
        Me.chkBeefStirFry.Text = "Beef Stir Fry"
        Me.chkBeefStirFry.UseVisualStyleBackColor = True
        '
        'chkChickenStirFry
        '
        Me.chkChickenStirFry.AutoSize = True
        Me.chkChickenStirFry.Location = New System.Drawing.Point(9, 118)
        Me.chkChickenStirFry.Name = "chkChickenStirFry"
        Me.chkChickenStirFry.Size = New System.Drawing.Size(97, 17)
        Me.chkChickenStirFry.TabIndex = 16
        Me.chkChickenStirFry.Text = "Chicken Stir fry"
        Me.chkChickenStirFry.UseVisualStyleBackColor = True
        '
        'chkPapWors
        '
        Me.chkPapWors.AutoSize = True
        Me.chkPapWors.Location = New System.Drawing.Point(9, 95)
        Me.chkPapWors.Name = "chkPapWors"
        Me.chkPapWors.Size = New System.Drawing.Size(94, 17)
        Me.chkPapWors.TabIndex = 15
        Me.chkPapWors.Text = "Pap and Wors"
        Me.chkPapWors.UseVisualStyleBackColor = True
        '
        'chkPasta
        '
        Me.chkPasta.AutoSize = True
        Me.chkPasta.Location = New System.Drawing.Point(9, 72)
        Me.chkPasta.Name = "chkPasta"
        Me.chkPasta.Size = New System.Drawing.Size(53, 17)
        Me.chkPasta.TabIndex = 14
        Me.chkPasta.Text = "Pasta"
        Me.chkPasta.UseVisualStyleBackColor = True
        '
        'chkPizza
        '
        Me.chkPizza.AutoSize = True
        Me.chkPizza.Location = New System.Drawing.Point(9, 49)
        Me.chkPizza.Name = "chkPizza"
        Me.chkPizza.Size = New System.Drawing.Size(51, 17)
        Me.chkPizza.TabIndex = 13
        Me.chkPizza.Text = "Pizza"
        Me.chkPizza.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(197, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "*You Can Choose More Than 1 Answer*"
        '
        'rdoSagreeEatOut
        '
        Me.rdoSagreeEatOut.AutoSize = True
        Me.rdoSagreeEatOut.Location = New System.Drawing.Point(31, 19)
        Me.rdoSagreeEatOut.Name = "rdoSagreeEatOut"
        Me.rdoSagreeEatOut.Size = New System.Drawing.Size(14, 13)
        Me.rdoSagreeEatOut.TabIndex = 8
        Me.rdoSagreeEatOut.TabStop = True
        Me.rdoSagreeEatOut.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Location = New System.Drawing.Point(442, 44)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(522, 32)
        Me.Panel1.TabIndex = 9
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(429, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(90, 26)
        Me.Label16.TabIndex = 16
        Me.Label16.Text = "Strongly Disagree" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "             (5)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(351, 1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 26)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Disagree" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    (4)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(266, 1)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(41, 26)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "Neutral" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    (3)"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(208, 1)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(35, 26)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "Agree" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  (2)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(117, 1)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(76, 26)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "Strongly Agree" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "          (1)"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Location = New System.Drawing.Point(442, 74)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(120, 157)
        Me.Panel2.TabIndex = 10
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 131)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(110, 26)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "I Like To Listen to the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Radio"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(19, 95)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(101, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "I Like To Watch TV"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(-1, 57)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 13)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "I Like To Watch Movies"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 19)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "I Like to Eat Out"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel3.Controls.Add(Me.rdoSagreeRadio)
        Me.Panel3.Controls.Add(Me.rdoSagreeTv)
        Me.Panel3.Controls.Add(Me.rdoSagreeMovies)
        Me.Panel3.Controls.Add(Me.rdoSagreeEatOut)
        Me.Panel3.Location = New System.Drawing.Point(562, 74)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(82, 157)
        Me.Panel3.TabIndex = 11
        '
        'rdoSagreeRadio
        '
        Me.rdoSagreeRadio.AutoSize = True
        Me.rdoSagreeRadio.Location = New System.Drawing.Point(31, 131)
        Me.rdoSagreeRadio.Name = "rdoSagreeRadio"
        Me.rdoSagreeRadio.Size = New System.Drawing.Size(14, 13)
        Me.rdoSagreeRadio.TabIndex = 11
        Me.rdoSagreeRadio.TabStop = True
        Me.rdoSagreeRadio.UseVisualStyleBackColor = True
        '
        'rdoSagreeTv
        '
        Me.rdoSagreeTv.AutoSize = True
        Me.rdoSagreeTv.Location = New System.Drawing.Point(31, 95)
        Me.rdoSagreeTv.Name = "rdoSagreeTv"
        Me.rdoSagreeTv.Size = New System.Drawing.Size(14, 13)
        Me.rdoSagreeTv.TabIndex = 10
        Me.rdoSagreeTv.TabStop = True
        Me.rdoSagreeTv.UseVisualStyleBackColor = True
        '
        'rdoSagreeMovies
        '
        Me.rdoSagreeMovies.AutoSize = True
        Me.rdoSagreeMovies.Location = New System.Drawing.Point(31, 57)
        Me.rdoSagreeMovies.Name = "rdoSagreeMovies"
        Me.rdoSagreeMovies.Size = New System.Drawing.Size(14, 13)
        Me.rdoSagreeMovies.TabIndex = 9
        Me.rdoSagreeMovies.TabStop = True
        Me.rdoSagreeMovies.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel4.Controls.Add(Me.rdoAgreeRadio)
        Me.Panel4.Controls.Add(Me.rdoAgreeTv)
        Me.Panel4.Controls.Add(Me.rdoAgreeMovies)
        Me.Panel4.Controls.Add(Me.rdoAgreeEatOut)
        Me.Panel4.Location = New System.Drawing.Point(641, 74)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(59, 157)
        Me.Panel4.TabIndex = 12
        '
        'rdoAgreeRadio
        '
        Me.rdoAgreeRadio.AutoSize = True
        Me.rdoAgreeRadio.Location = New System.Drawing.Point(30, 131)
        Me.rdoAgreeRadio.Name = "rdoAgreeRadio"
        Me.rdoAgreeRadio.Size = New System.Drawing.Size(14, 13)
        Me.rdoAgreeRadio.TabIndex = 15
        Me.rdoAgreeRadio.TabStop = True
        Me.rdoAgreeRadio.UseVisualStyleBackColor = True
        '
        'rdoAgreeTv
        '
        Me.rdoAgreeTv.AutoSize = True
        Me.rdoAgreeTv.Location = New System.Drawing.Point(30, 95)
        Me.rdoAgreeTv.Name = "rdoAgreeTv"
        Me.rdoAgreeTv.Size = New System.Drawing.Size(14, 13)
        Me.rdoAgreeTv.TabIndex = 14
        Me.rdoAgreeTv.TabStop = True
        Me.rdoAgreeTv.UseVisualStyleBackColor = True
        '
        'rdoAgreeMovies
        '
        Me.rdoAgreeMovies.AutoSize = True
        Me.rdoAgreeMovies.Location = New System.Drawing.Point(30, 57)
        Me.rdoAgreeMovies.Name = "rdoAgreeMovies"
        Me.rdoAgreeMovies.Size = New System.Drawing.Size(14, 13)
        Me.rdoAgreeMovies.TabIndex = 13
        Me.rdoAgreeMovies.TabStop = True
        Me.rdoAgreeMovies.UseVisualStyleBackColor = True
        '
        'rdoAgreeEatOut
        '
        Me.rdoAgreeEatOut.AutoSize = True
        Me.rdoAgreeEatOut.Location = New System.Drawing.Point(30, 19)
        Me.rdoAgreeEatOut.Name = "rdoAgreeEatOut"
        Me.rdoAgreeEatOut.Size = New System.Drawing.Size(14, 13)
        Me.rdoAgreeEatOut.TabIndex = 12
        Me.rdoAgreeEatOut.TabStop = True
        Me.rdoAgreeEatOut.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel5.Controls.Add(Me.rdoDisRadio)
        Me.Panel5.Controls.Add(Me.rdoDisTV)
        Me.Panel5.Controls.Add(Me.rdoDisMovies)
        Me.Panel5.Controls.Add(Me.rdoDisEatOut)
        Me.Panel5.Location = New System.Drawing.Point(765, 74)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(99, 157)
        Me.Panel5.TabIndex = 14
        '
        'rdoDisRadio
        '
        Me.rdoDisRadio.AutoSize = True
        Me.rdoDisRadio.Location = New System.Drawing.Point(43, 131)
        Me.rdoDisRadio.Name = "rdoDisRadio"
        Me.rdoDisRadio.Size = New System.Drawing.Size(14, 13)
        Me.rdoDisRadio.TabIndex = 23
        Me.rdoDisRadio.TabStop = True
        Me.rdoDisRadio.UseVisualStyleBackColor = True
        '
        'rdoDisTV
        '
        Me.rdoDisTV.AutoSize = True
        Me.rdoDisTV.Location = New System.Drawing.Point(43, 95)
        Me.rdoDisTV.Name = "rdoDisTV"
        Me.rdoDisTV.Size = New System.Drawing.Size(14, 13)
        Me.rdoDisTV.TabIndex = 22
        Me.rdoDisTV.TabStop = True
        Me.rdoDisTV.UseVisualStyleBackColor = True
        '
        'rdoDisMovies
        '
        Me.rdoDisMovies.AutoSize = True
        Me.rdoDisMovies.Location = New System.Drawing.Point(43, 57)
        Me.rdoDisMovies.Name = "rdoDisMovies"
        Me.rdoDisMovies.Size = New System.Drawing.Size(14, 13)
        Me.rdoDisMovies.TabIndex = 21
        Me.rdoDisMovies.TabStop = True
        Me.rdoDisMovies.UseVisualStyleBackColor = True
        '
        'rdoDisEatOut
        '
        Me.rdoDisEatOut.AutoSize = True
        Me.rdoDisEatOut.Location = New System.Drawing.Point(43, 19)
        Me.rdoDisEatOut.Name = "rdoDisEatOut"
        Me.rdoDisEatOut.Size = New System.Drawing.Size(14, 13)
        Me.rdoDisEatOut.TabIndex = 20
        Me.rdoDisEatOut.TabStop = True
        Me.rdoDisEatOut.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel6.Controls.Add(Me.rdoNeutRadio)
        Me.Panel6.Controls.Add(Me.rdoNeutTV)
        Me.Panel6.Controls.Add(Me.rdoNeutMovies)
        Me.Panel6.Controls.Add(Me.rdoNeutEatOut)
        Me.Panel6.Location = New System.Drawing.Point(699, 74)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(68, 157)
        Me.Panel6.TabIndex = 13
        '
        'rdoNeutRadio
        '
        Me.rdoNeutRadio.AutoSize = True
        Me.rdoNeutRadio.Location = New System.Drawing.Point(25, 131)
        Me.rdoNeutRadio.Name = "rdoNeutRadio"
        Me.rdoNeutRadio.Size = New System.Drawing.Size(14, 13)
        Me.rdoNeutRadio.TabIndex = 19
        Me.rdoNeutRadio.TabStop = True
        Me.rdoNeutRadio.UseVisualStyleBackColor = True
        '
        'rdoNeutTV
        '
        Me.rdoNeutTV.AutoSize = True
        Me.rdoNeutTV.Location = New System.Drawing.Point(25, 95)
        Me.rdoNeutTV.Name = "rdoNeutTV"
        Me.rdoNeutTV.Size = New System.Drawing.Size(14, 13)
        Me.rdoNeutTV.TabIndex = 18
        Me.rdoNeutTV.TabStop = True
        Me.rdoNeutTV.UseVisualStyleBackColor = True
        '
        'rdoNeutMovies
        '
        Me.rdoNeutMovies.AutoSize = True
        Me.rdoNeutMovies.Location = New System.Drawing.Point(25, 57)
        Me.rdoNeutMovies.Name = "rdoNeutMovies"
        Me.rdoNeutMovies.Size = New System.Drawing.Size(14, 13)
        Me.rdoNeutMovies.TabIndex = 17
        Me.rdoNeutMovies.TabStop = True
        Me.rdoNeutMovies.UseVisualStyleBackColor = True
        '
        'rdoNeutEatOut
        '
        Me.rdoNeutEatOut.AutoSize = True
        Me.rdoNeutEatOut.Location = New System.Drawing.Point(25, 19)
        Me.rdoNeutEatOut.Name = "rdoNeutEatOut"
        Me.rdoNeutEatOut.Size = New System.Drawing.Size(14, 13)
        Me.rdoNeutEatOut.TabIndex = 16
        Me.rdoNeutEatOut.TabStop = True
        Me.rdoNeutEatOut.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel7.Controls.Add(Me.rdoSdisRadio)
        Me.Panel7.Controls.Add(Me.rdoSdisTV)
        Me.Panel7.Controls.Add(Me.rdoSdisMovies)
        Me.Panel7.Controls.Add(Me.rdoSdisEatOut)
        Me.Panel7.Location = New System.Drawing.Point(862, 74)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(102, 157)
        Me.Panel7.TabIndex = 15
        '
        'rdoSdisRadio
        '
        Me.rdoSdisRadio.AutoSize = True
        Me.rdoSdisRadio.Location = New System.Drawing.Point(40, 131)
        Me.rdoSdisRadio.Name = "rdoSdisRadio"
        Me.rdoSdisRadio.Size = New System.Drawing.Size(14, 13)
        Me.rdoSdisRadio.TabIndex = 27
        Me.rdoSdisRadio.TabStop = True
        Me.rdoSdisRadio.UseVisualStyleBackColor = True
        '
        'rdoSdisTV
        '
        Me.rdoSdisTV.AutoSize = True
        Me.rdoSdisTV.Location = New System.Drawing.Point(40, 95)
        Me.rdoSdisTV.Name = "rdoSdisTV"
        Me.rdoSdisTV.Size = New System.Drawing.Size(14, 13)
        Me.rdoSdisTV.TabIndex = 26
        Me.rdoSdisTV.TabStop = True
        Me.rdoSdisTV.UseVisualStyleBackColor = True
        '
        'rdoSdisMovies
        '
        Me.rdoSdisMovies.AutoSize = True
        Me.rdoSdisMovies.Location = New System.Drawing.Point(40, 57)
        Me.rdoSdisMovies.Name = "rdoSdisMovies"
        Me.rdoSdisMovies.Size = New System.Drawing.Size(14, 13)
        Me.rdoSdisMovies.TabIndex = 25
        Me.rdoSdisMovies.TabStop = True
        Me.rdoSdisMovies.UseVisualStyleBackColor = True
        '
        'rdoSdisEatOut
        '
        Me.rdoSdisEatOut.AutoSize = True
        Me.rdoSdisEatOut.Location = New System.Drawing.Point(40, 19)
        Me.rdoSdisEatOut.Name = "rdoSdisEatOut"
        Me.rdoSdisEatOut.Size = New System.Drawing.Size(14, 13)
        Me.rdoSdisEatOut.TabIndex = 24
        Me.rdoSdisEatOut.TabStop = True
        Me.rdoSdisEatOut.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(464, 431)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(196, 43)
        Me.btnSubmit.TabIndex = 16
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'frmFillOutSurvey
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1112, 557)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmFillOutSurvey"
        Me.Text = "Take your Survey"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtAge As TextBox
    Friend WithEvents txtContactNum As TextBox
    Friend WithEvents txtFirstNames As TextBox
    Friend WithEvents txtSuename As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkOther As CheckBox
    Friend WithEvents chkBeefStirFry As CheckBox
    Friend WithEvents chkChickenStirFry As CheckBox
    Friend WithEvents chkPapWors As CheckBox
    Friend WithEvents chkPasta As CheckBox
    Friend WithEvents chkPizza As CheckBox
    Friend WithEvents Label7 As Label

    Private Sub frmFillOutSurvey_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Friend WithEvents rdoSagreeEatOut As RadioButton
    Friend WithEvents dtDate As DateTimePicker
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents rdoSagreeRadio As RadioButton
    Friend WithEvents rdoSagreeTv As RadioButton
    Friend WithEvents rdoSagreeMovies As RadioButton
    Friend WithEvents rdoAgreeRadio As RadioButton
    Friend WithEvents rdoAgreeTv As RadioButton
    Friend WithEvents rdoAgreeMovies As RadioButton
    Friend WithEvents rdoAgreeEatOut As RadioButton
    Friend WithEvents rdoDisRadio As RadioButton
    Friend WithEvents rdoDisTV As RadioButton
    Friend WithEvents rdoDisMovies As RadioButton
    Friend WithEvents rdoDisEatOut As RadioButton
    Friend WithEvents rdoNeutRadio As RadioButton
    Friend WithEvents rdoNeutTV As RadioButton
    Friend WithEvents rdoNeutMovies As RadioButton
    Friend WithEvents rdoNeutEatOut As RadioButton
    Friend WithEvents rdoSdisRadio As RadioButton
    Friend WithEvents rdoSdisTV As RadioButton
    Friend WithEvents rdoSdisMovies As RadioButton
    Friend WithEvents rdoSdisEatOut As RadioButton
    Friend WithEvents btnSubmit As Button


    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        Dim surname, firstName, ContactNumber, age As String
        surname = txtSuename.Text
        firstName = txtFirstNames.Text
        ContactNumber = txtContactNum.Text
        datte = dtDate.ToString
        Try
            Dim objUser As New UserDetails(surname, firstName, ContactNumber)

            age = CInt(txtAge.Text)


            If arCnt > arAge.Length Then

                MessageBox.Show("surveys closed", "UNAVAILABLE", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else
                arSurveys(arCnt) = objUser
                arAge(arCnt) = age
                arCnt += 1
                FavFood()
                Ratings()
            End If
            Clear()
            chkClear()
        Catch ex As Exception
            Clear()
            chkClear()
            txtSuename.Focus()
        End Try



    End Sub
    Private Sub Clear()
        txtSuename.Text = ""
        txtFirstNames.Text = ""
        txtContactNum.Text = ""
        txtAge.Text = ""
        txtSuename.Focus()
    End Sub

    Public Sub FavFood()



        If chkPizza.Checked = True Then
            pizza += 1

        End If

        If chkPasta.Checked = True Then
            pasta += 1
        End If
        If chkPapWors.Checked = True Then
            papWors += 1
        End If
        If chkChickenStirFry.Checked = True Then
            ChicknFr += 1
        End If
        If chkBeefStirFry.Checked = True Then
            BeefFr += 1
        End If
        If chkOther.Checked = True Then
            other += 1
        End If

    End Sub

    Private Sub chkClear()
        chkOther.Checked = False
        chkBeefStirFry.Checked = False
        chkChickenStirFry.Checked = False
        chkPapWors.Checked = False
        chkPasta.Checked = False
        chkPizza.Checked = False

        rdoSagreeEatOut.Checked = False
        rdoAgreeEatOut.Checked = False
        rdoDisEatOut.Checked = False
        rdoNeutEatOut.Checked = False
        rdoSdisEatOut.Checked = False

        rdoSagreeMovies.Checked = False
        rdoAgreeMovies.Checked = False
        rdoNeutMovies.Checked = False
        rdoDisMovies.Checked = False
        rdoSdisMovies.Checked = False

        rdoSagreeRadio.Checked = False
        rdoAgreeRadio.Checked = False
        rdoNeutTV.Checked = False
        rdoDisRadio.Checked = False
        rdoSdisRadio.Checked = False

    End Sub

    Public Sub Ratings()
        If rdoSagreeEatOut.Checked = True Then
            EatOutRate += 1
        ElseIf rdoAgreeEatOut.Checked = True Then
            EatOutRate += 2
        ElseIf rdoNeutEatOut.Checked = True Then
            EatOutRate += 3
        ElseIf rdoDisEatOut.Checked = True Then
            EatOutRate += 4
        ElseIf rdoSdisEatOut.Checked = True Then

            EatOutRate += 5
        End If

        If rdoSagreeMovies.Checked = True Then
            watchMovies += 1
        ElseIf rdoAgreeMovies.Checked = True Then
            watchMovies += 2
        ElseIf rdoNeutMovies.Checked = True Then
            watchMovies += 3
        ElseIf rdoDisMovies.Checked = True Then
            watchMovies += 4
        ElseIf rdoSdisMovies.Checked = True Then
            watchMovies += 5
        End If

        If rdoSagreeTv.Checked = True Then
            watchTv += 1
        ElseIf rdoAgreeTv.Checked = True Then
            watchTv += 2

        ElseIf rdoNeutTV.Checked = True Then
            watchTv += 3

        ElseIf rdoDisTV.Checked = True Then
            watchTv += 4

        ElseIf rdoSdisTV.Checked = True Then
            watchTv += 5

        End If

        If rdoSagreeRadio.Checked = True Then
            Lradio += 1
        ElseIf rdoAgreeRadio.Checked = True Then
            Lradio += 2

        ElseIf rdoNeutTV.Checked = True Then
            Lradio += 3

        ElseIf rdoDisRadio.Checked = True Then
            Lradio += 4

        ElseIf rdoSdisRadio.Checked = True Then
            Lradio += 5

        End If

    End Sub


End Class
